---
title: MDIO Frame Format
created: 2022-Oct-31
tags:
  - 'garden'
  - 'permanent/linking'
publish: False
---

![[Pasted image 20221031173613.png]]

source:: https://ewiki.marvell.com/pages/worddav/preview.action?fileName=TD-001757+Lynx+400G+Datasheet_DRAFT_2.pdf&pageId=268541540



