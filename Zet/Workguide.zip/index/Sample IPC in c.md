---
title: Sample IPC in c
created: 2022-Oct-31
tags:
  - 'garden'
  - 'permanent/linking'
publish: False
---
[[notes/concept/IPC feature|IPC]]

![[client.c]]

![[server.c]]



