---

kanban-plugin: basic

---

## TODO

- [ ] Add more ANLT sample
- [ ] [[Interns - Create environment python for por_dr in lab repo]]


## WAITING



## DOING



## DONE



***

## Archive

- [x] [[Dashboard change API]] ✅ 2022-09-21
- [x] [[RETCSW-112 Warning complain checking]] ✅ 2022-09-21
- [x] [[spica+ loopcount clear]] ✅ 2022-09-21
- [x] [[Add sample to profile APIs execute time]] ✅ 2022-09-21
- [x] RETCSW-125 Screening part for lynx to release ✅ 2022-09-21
- [x] [[SPICSW-351 API Support PG4 package]]<br>- Lab 5010 ✅ 2022-09-21
- [x] [[Spica+ - Xbar query on SWIG after set up delegate]] ✅ 2022-09-21
- [ ] [[Issue - Supply voltage sweeping test]]
- [ ] [[Spica5 - Universal API develop for bringup phase]]

%% kanban:settings
```
{"kanban-plugin":"basic","show-checkboxes":false}
```
%%