```
sed -i 's/INPHI_HAS_INLINE_APP_FW/INPHI_HAS_CPL_INLINE_APP_FW/g' cpl_api.h
```