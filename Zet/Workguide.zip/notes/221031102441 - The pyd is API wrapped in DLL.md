---
title: The pyd is API wrapped in DLL
UID: 221031102441
created: 31-Oct-2022
tags:
  - 'created/2022/Oct/31'
  - 'evergreen'
  - 'permanent/fact'
aliases: '221031102441'
publish: False
---
## Notes:
The pyd is the API wrapped in DLL

the odsp_api.py is just a wrapper that tells python how to call functions in the DLL/PYD.

source:: Brad mention in [[20221031 - importing .pyd files issue email]]

## Relate: