---
title: The hsc api build machine is setup to compile with Visual Studio Express 2013
UID: 221031103328
created: 31-Oct-2022
tags:
  - 'created/2022/Oct/31'
  - 'evergreen'
  - 'permanent/fact'
aliases: '221031103328'
publish: False
---
## Notes:
The hsc api build machine is setup to compile with Visual Studio Express 2013

The 2 files are required if using 64b python

- msvcp120.dll
- msvcr120.dll

source:: [[20221031 - importing .pyd files issue email]]
## Relate: