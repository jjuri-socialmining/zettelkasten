---
title: Comment in batch script
created: 2022-Oct-24
tags:
  - 'permanent/common'
publish: False
---
up:: [[batch script]]

Comment
```batch
:: comment here
rem comment here
```
