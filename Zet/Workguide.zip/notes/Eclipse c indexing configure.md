---
title: Eclipse c indexing configure
created: 2022-Oct-26
tags:
  - 'permanent/howto'
publish: True
---

To add paths containing code to parse, follow these steps :  
1. Right click on the project  
2. Select Properties  
3. Go to C/C++ General  
4. Go to Path and Symbols  
5. If the paths are missing, add paths.

To re-parse the code follow these steps :  
1. Right click on the project  
2. Select Index  
3. Rebuild



