---
title: Jenkins pipeline use groovy language to confuge jenkins job
created: 2022-Oct-24
tags:
  - 'permanent/fact'
publish: False
---

![[Pasted image 20221024112754.png]]


