---
title: swig
UID: 221028165118
created: 28-Oct-2022
tags:
  - 'created/2022/Oct/28'
  - 'permanent/concept'
aliases:
  -
publish: False
---


- [[Swig Parameter]]
- [[Swig Constants]]


Swig c build on linux -> \_hsc_api.so
Swig c build on window -> \_hsc_api.pyd


![[PyTutorial98.pdf]]

[[hsc sw tools MOC]]
- ![[Pasted image 20221018122949.png]]