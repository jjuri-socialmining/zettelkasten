---
title: Active Electrical Cable (AEC)
UID: 221115132454
created: 15-Nov-2022
tags:
  - 'created/2022/Nov/15'
  - 'permanent/concept'
aliases:
  - Active Electrical Cable market
  - AEC
  - Active Cable
publish: False
---

- [[Lynx Alaska_A tapeout email]]
