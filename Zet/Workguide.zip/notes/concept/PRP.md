---
title: PRP
UID: 221026150630
created: 26-Oct-2022
tags:
  - 'created/2022/Oct/26'
  - 'permanent/concept'
aliases:
  -
publish: False
---


## Related:
- https://ewiki.marvell.com/pages/viewpage.action?pageId=229654008



