---
title: groovy
created: 2022-Oct-24
tags:
  - 'permanent/concept'
aliases:
  - Apache Groovy
publish: False
---
## Notes:
groovy là ngôn ngữ script để run automate framework.
## Related:
- [[Jenkins]]
- 


