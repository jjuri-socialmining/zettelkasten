---
title: MDIO
UID: 221031173401
created: 31-Oct-2022
tags:
  - 'created/2022/Oct/31'
  - 'permanent/concept'
aliases:
  -
publish: False
---

[[MDIO Frame Format]]

## Reference:
- https://ewiki.marvell.com/display/AEC/AEC-200G?preview=%2F268541540%2F268541554%2FTD-001757+Lynx+400G+Datasheet_DRAFT_2.pdf



