---
title: olympus
UID: 221031104453
created: 31-Oct-2022
tags:
  - 'created/2022/Oct/31'
  - 'permanent/concept'
aliases:
  - olympus.pyd
publish: False
---






# Olympus


## C example

```
hsc_status_t inphi_olympus_open(uint32_t mb)
```

[[Run example]]

- Lib Olympus được build sẵn trên server inphi ở trong thư viện prebuild
	- http://sw.inphi-corp.local/projects/sw/inphi_explorer/prebuilt/olympus.api/
	- http://sw.inphi-corp.local/projects/sw/inphi_explorer/prebuilt/olympus/
	- ![[Pasted image 20220510102807.png]]

[[Olympus install source files]]

## Ideas:
- [x] Tìm olympus api documment [[Olympus.html]]

## Related issues:
- [[ATB sample script issue]]
- [[Read register on gui Script via olympus]]
- [[How to scan device via Olympus]]