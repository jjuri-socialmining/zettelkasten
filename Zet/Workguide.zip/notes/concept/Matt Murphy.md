---
title: Matt Murphy
created: 2022-Oct-04
tags:
  - 'permanent/people'
aliases:
  - Marvell CEO
---

Matt Murphy is President and Chief Executive Officer (CEO) of [[Marvell]]


