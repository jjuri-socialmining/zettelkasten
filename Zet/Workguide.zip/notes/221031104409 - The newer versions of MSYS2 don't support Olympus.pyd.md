---
title: The newer versions of MSYS2 don't support Olympus.pyd
UID: 221031104409
created: 31-Oct-2022
tags:
  - 'created/2022/Oct/31'
  - 'evergreen'
  - 'permanent/fact'
aliases: '221031104409'
publish: False
---
## Notes:
The newer versions of MSYS2 don't support [[notes/concept/olympus|olympus.pyd]]

source:: [[Brad Elliott|Brad]] mention in [[20221031 - importing .pyd files issue email]]
## Relate: