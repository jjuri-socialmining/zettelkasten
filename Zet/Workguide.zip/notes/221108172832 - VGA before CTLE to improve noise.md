---
title: VGA before CTLE to improve noise
UID: 221108172832
created: 08-Nov-2022
tags:
  - 'created/2022/Nov/08'
  - 'evergreen'
  - 'permanent/fact'
aliases: '221108172832'
publish: False
---
## Notes:
[[VGA]] before [[CTLE]] to improve noise

source:: [[ISSCC2020-06_Visuals.pdf]]
## Relate: