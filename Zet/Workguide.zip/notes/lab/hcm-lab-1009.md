---
tags: 
project: spica5
user: hcm-lab-1009\hcmswlab
pass: hcmswL@B123
ip: 
---
up:: [[Lab list]]

```
hcm-lab-1009  
user: hcm-lab-1009\hcmswlab
pass: hcmswL@B123
```

```
-----Olympus Version------
     2022.16 10-25-2022
-----INDEX (0)------
General Info:          index=0, serial number=1417, name=ZEUS-3 SN 1417
Motherboard Info:      Name=ZEUS-3 SN 1417, version=0, serial number=1417
                       FPGA=12.8 Artix 7 FPGA, FW=6.1 Firmware for USB FX3 ARM Controller
Daughterboard Info:    Name=CERES-6.S1 SN 13, Board ID=6662(0x1a06), serial number=13
Chip Info:             Name=, Chip ID=114(0x72)
-- Scanning PHY in bus 0
  xx Phy=0x0 0b90
  xx Phy=0x1 0ffff


-----INDEX (1)------
General Info:          index=1, serial number=1390, name=ZEUS-3 SN 1390
Motherboard Info:      Name=ZEUS-3 SN 1390, version=0, serial number=1390
                       FPGA=12.8 Artix 7 FPGA, FW=6.1 Firmware for USB FX3 ARM Controller
Daughterboard Info:    Name=ANTEVORTA-1C.18 SN 195, Board ID=4353(0x1101), serial number=195
Chip Info:             Name=PORRIMA-10x13-A0, Chip ID=44(0x2c)
-- Scanning PHY in bus 0
  -- Found phy=0x0 Die:Porrima Die
  xx Phy=0x1 0ffff
  xx Phy=0x2 0ffff

(base) C:\usr\GUI>
```