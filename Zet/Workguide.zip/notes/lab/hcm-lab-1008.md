---
tags: 
project: 
user:
pass: 
ip: 
---
up:: [[Lab list]]

```
hcm-lab-1008  
hcm-lab-1008\hcmswlab  
pass: hcmswL@B123
```