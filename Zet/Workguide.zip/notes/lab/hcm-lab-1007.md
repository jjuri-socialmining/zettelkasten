---
tags: 
project: 
user:
pass: 
ip: 
---
up:: [[Lab list]]

```
hcm-lab-1007
hcm-lab-1007\hcmswlab
pass: hcmswL@B123
```