---
tags: 
project: 
user:
pass: 
---
up:: [[Lab list]]
up:: [[Spica5 labs]]

```
PC: ott-lab-6006  
User: OTT-LAB-6006\ottlab
Password: Ottlab123
```

```
Board type: Xtal OscilatorPC: ott-lab-6008  
User: OTT-LAB-6008\ottlab  
Password: Ottlab123  
Board type: Ext Clk
```