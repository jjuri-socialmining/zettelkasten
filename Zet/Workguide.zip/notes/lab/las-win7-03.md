---
tags: jenkins, server
user: LAS-WIN7-03\las-win7-03-user
pass: Ottlab123
---

Server to build wraper win python
Jenkins link:
- http://sw.inphi-corp.local/jenkins/computer/las-win7-03/

```
las-win7-03  
user: LAS-WIN7-03\las-win7-03-user  
pass: Ottlab123
```

![[20221019121641 ~ las-win7-03.png]]
