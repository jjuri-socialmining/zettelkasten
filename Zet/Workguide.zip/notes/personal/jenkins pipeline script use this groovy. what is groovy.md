---
title: jenkins pipeline script use this groovy. what is groovy
created: 2022-Oct-24
tags:
  - 'personal'
publish: False
---
## Permanents
[[groovy]]

## Research


