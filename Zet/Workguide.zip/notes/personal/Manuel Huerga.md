Ku này là team [[notes/Regression test]], do thằng [[Ignacio]] mới nghỉ, không còn làm cho lynx nữa
