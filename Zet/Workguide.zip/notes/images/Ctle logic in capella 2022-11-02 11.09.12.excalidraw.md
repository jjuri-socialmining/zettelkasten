---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
#define CTLE_TBL_SIZE 31

static uint8_t g_ctle_lookup[CTLE_TBL_SIZE][2] = {
    // CTLE1_PEAK and CTLE2_PEAK
    { 0, 0 },
    { 0, 1 },
    { 1, 1 },
    { 2, 1 },
    { 2, 2 },
    { 3, 2 },
    { 3, 3 },
    { 4, 3 },
    { 4, 4 },
    { 5, 4 },
    { 5, 5 },
    { 6, 5 },
    { 6, 6 },
    { 7, 6 },
    { 7, 7 },
    { 8, 7 },
    { 8, 8 },
    { 9, 8 },
    { 9, 9 },
    { 10, 9 },
    { 10, 10 },
    { 11, 10 },
    { 11, 11 },
    { 12, 11 },
    { 12, 12 },
    { 13, 12 },
    { 13, 13 },
    { 14, 13 },
    { 14, 14 },
    { 15, 14 },
    { 15, 15 }
}; ^xqdy5PIq

DSP_GAIN ^MqAA19KK

DFE_MODE ^NGFVl5GH

SIGNALLING ^2M0sWZ9G

CTLE_IDX ^3e5G3a7c

BAUDRATE ^JkcGL7OB

DSP_MODE ^QZT6HUAL

AFE_TRIM ^wsTNs44g

CTLE1/2 ^DkpmNHuR

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "xqdy5PIq",
			"type": "text",
			"x": 186,
			"y": -197,
			"width": 587,
			"height": 864,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 2091696863,
			"version": 9,
			"versionNonce": 1062390367,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"text": "#define CTLE_TBL_SIZE 31\n\nstatic uint8_t g_ctle_lookup[CTLE_TBL_SIZE][2] = {\n    // CTLE1_PEAK and CTLE2_PEAK\n    { 0, 0 },\n    { 0, 1 },\n    { 1, 1 },\n    { 2, 1 },\n    { 2, 2 },\n    { 3, 2 },\n    { 3, 3 },\n    { 4, 3 },\n    { 4, 4 },\n    { 5, 4 },\n    { 5, 5 },\n    { 6, 5 },\n    { 6, 6 },\n    { 7, 6 },\n    { 7, 7 },\n    { 8, 7 },\n    { 8, 8 },\n    { 9, 8 },\n    { 9, 9 },\n    { 10, 9 },\n    { 10, 10 },\n    { 11, 10 },\n    { 11, 11 },\n    { 12, 11 },\n    { 12, 12 },\n    { 13, 12 },\n    { 13, 13 },\n    { 14, 13 },\n    { 14, 14 },\n    { 15, 14 },\n    { 15, 15 }\n};",
			"rawText": "#define CTLE_TBL_SIZE 31\n\nstatic uint8_t g_ctle_lookup[CTLE_TBL_SIZE][2] = {\n    // CTLE1_PEAK and CTLE2_PEAK\n    { 0, 0 },\n    { 0, 1 },\n    { 1, 1 },\n    { 2, 1 },\n    { 2, 2 },\n    { 3, 2 },\n    { 3, 3 },\n    { 4, 3 },\n    { 4, 4 },\n    { 5, 4 },\n    { 5, 5 },\n    { 6, 5 },\n    { 6, 6 },\n    { 7, 6 },\n    { 7, 7 },\n    { 8, 7 },\n    { 8, 8 },\n    { 9, 8 },\n    { 9, 9 },\n    { 10, 9 },\n    { 10, 10 },\n    { 11, 10 },\n    { 11, 11 },\n    { 12, 11 },\n    { 12, 12 },\n    { 13, 12 },\n    { 13, 13 },\n    { 14, 13 },\n    { 14, 14 },\n    { 15, 14 },\n    { 15, 15 }\n};",
			"fontSize": 20,
			"fontFamily": 3,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 859,
			"containerId": null,
			"originalText": "#define CTLE_TBL_SIZE 31\n\nstatic uint8_t g_ctle_lookup[CTLE_TBL_SIZE][2] = {\n    // CTLE1_PEAK and CTLE2_PEAK\n    { 0, 0 },\n    { 0, 1 },\n    { 1, 1 },\n    { 2, 1 },\n    { 2, 2 },\n    { 3, 2 },\n    { 3, 3 },\n    { 4, 3 },\n    { 4, 4 },\n    { 5, 4 },\n    { 5, 5 },\n    { 6, 5 },\n    { 6, 6 },\n    { 7, 6 },\n    { 7, 7 },\n    { 8, 7 },\n    { 8, 8 },\n    { 9, 8 },\n    { 9, 9 },\n    { 10, 9 },\n    { 10, 10 },\n    { 11, 10 },\n    { 11, 11 },\n    { 12, 11 },\n    { 12, 12 },\n    { 13, 12 },\n    { 13, 13 },\n    { 14, 13 },\n    { 14, 14 },\n    { 15, 14 },\n    { 15, 15 }\n};"
		},
		{
			"id": "uOHwbAmora25BFTvhCxtK",
			"type": "rectangle",
			"x": 1416.6161283724846,
			"y": 276.57876605344296,
			"width": 183,
			"height": 89,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 15635647,
			"version": 131,
			"versionNonce": 1877655231,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "MqAA19KK"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "qchnuGuqEG19CRf0kjfxM",
					"type": "arrow"
				}
			],
			"updated": 1667362732415,
			"link": null,
			"locked": false
		},
		{
			"id": "MqAA19KK",
			"type": "text",
			"x": 1460.6161283724846,
			"y": 309.07876605344296,
			"width": 95,
			"height": 24,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1727461169,
			"version": 81,
			"versionNonce": 677914239,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"text": "DSP_GAIN",
			"rawText": "DSP_GAIN",
			"fontSize": 20,
			"fontFamily": 3,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 19,
			"containerId": "uOHwbAmora25BFTvhCxtK",
			"originalText": "DSP_GAIN"
		},
		{
			"id": "uwMl9R8aiRms1ObTra34l",
			"type": "rectangle",
			"x": 1412.5160917513908,
			"y": 4.578735535864524,
			"width": 180,
			"height": 93,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1636667601,
			"version": 85,
			"versionNonce": 242402545,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "NGFVl5GH"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				}
			],
			"updated": 1667362613568,
			"link": null,
			"locked": false
		},
		{
			"id": "NGFVl5GH",
			"type": "text",
			"x": 1455.0160917513908,
			"y": 39.078735535864524,
			"width": 95,
			"height": 24,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 453029329,
			"version": 46,
			"versionNonce": 1522335391,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"text": "DFE_MODE",
			"rawText": "DFE_MODE",
			"fontSize": 20,
			"fontFamily": 3,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 19,
			"containerId": "uwMl9R8aiRms1ObTra34l",
			"originalText": "DFE_MODE"
		},
		{
			"id": "6wNYJIGzrswwbVq9N7hNJ",
			"type": "arrow",
			"x": 1497.716164993578,
			"y": 107.07865924191937,
			"width": 3.199951171875,
			"height": 155.20001220703136,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 340870321,
			"version": 50,
			"versionNonce": 2056191697,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					3.199951171875,
					155.20001220703136
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "uwMl9R8aiRms1ObTra34l",
				"focus": 0.0654642546192749,
				"gap": 9.49992370605483
			},
			"endBinding": {
				"elementId": "uOHwbAmora25BFTvhCxtK",
				"focus": -0.06478921155652005,
				"gap": 14.300094604492244
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "rectangle",
			"version": 280,
			"versionNonce": 457395569,
			"isDeleted": false,
			"id": "OitInrRod0ly0KMRuVxn2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1122.2162870638906,
			"y": 274.5786592419192,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 89,
			"seed": 458299903,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "2M0sWZ9G",
					"type": "text"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "E-KGEvX7Xtty7f5HLhn3O",
					"type": "arrow"
				}
			],
			"updated": 1667362754181,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 247,
			"versionNonce": 1858665649,
			"isDeleted": false,
			"id": "2M0sWZ9G",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1154.2162870638906,
			"y": 307.0786592419192,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 119,
			"height": 24,
			"seed": 1365559665,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 3,
			"text": "SIGNALLING",
			"rawText": "SIGNALLING",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "OitInrRod0ly0KMRuVxn2",
			"originalText": "SIGNALLING"
		},
		{
			"type": "rectangle",
			"version": 376,
			"versionNonce": 1028256191,
			"isDeleted": false,
			"id": "9K6c3X9aSrNCfZ4H2lxUB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1444.8379640387172,
			"y": 659.2011093287254,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 89,
			"seed": 1325736255,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "3e5G3a7c",
					"type": "text"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "z1PJwNnSC3Rtrq227xe45",
					"type": "arrow"
				},
				{
					"id": "ncO7vNZlL-0jWA9AMN0Bq",
					"type": "arrow"
				}
			],
			"updated": 1667362740706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 331,
			"versionNonce": 1704514303,
			"isDeleted": false,
			"id": "3e5G3a7c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1488.8379640387172,
			"y": 691.7011093287254,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 95,
			"height": 24,
			"seed": 1749538353,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1667362708035,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 3,
			"text": "CTLE_IDX",
			"rawText": "CTLE_IDX",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "9K6c3X9aSrNCfZ4H2lxUB",
			"originalText": "CTLE_IDX"
		},
		{
			"type": "rectangle",
			"version": 238,
			"versionNonce": 1752487231,
			"isDeleted": false,
			"id": "x5NOCHn16Y9nI4NvfDgEM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 863.4161161654529,
			"y": 272.97886676145066,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 89,
			"seed": 607806193,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "JkcGL7OB",
					"type": "text"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "1gC3xSY2hlelmgatbdFTy",
					"type": "arrow"
				}
			],
			"updated": 1667362757576,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 199,
			"versionNonce": 222577777,
			"isDeleted": false,
			"id": "JkcGL7OB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 907.4161161654529,
			"y": 305.47886676145066,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 95,
			"height": 24,
			"seed": 491143327,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 3,
			"text": "BAUDRATE",
			"rawText": "BAUDRATE",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "x5NOCHn16Y9nI4NvfDgEM",
			"originalText": "BAUDRATE"
		},
		{
			"type": "rectangle",
			"version": 329,
			"versionNonce": 886455633,
			"isDeleted": false,
			"id": "OO6j9nHhAbHDC3ZNobjZ7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1685.8160185092036,
			"y": 276.1785737927008,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 89,
			"seed": 1843537695,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "QZT6HUAL",
					"type": "text"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "nQ00hZqbTFBfULNEHlLBF",
					"type": "arrow"
				}
			],
			"updated": 1667362745464,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 303,
			"versionNonce": 839159377,
			"isDeleted": false,
			"id": "QZT6HUAL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1729.8160185092036,
			"y": 308.6785737927008,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 95,
			"height": 24,
			"seed": 1980669521,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 3,
			"text": "DSP_MODE",
			"rawText": "DSP_MODE",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "OO6j9nHhAbHDC3ZNobjZ7",
			"originalText": "DSP_MODE"
		},
		{
			"type": "rectangle",
			"version": 361,
			"versionNonce": 1832922975,
			"isDeleted": false,
			"id": "1DXJsGUwwf5Yhc026qC8F",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1935.816140579516,
			"y": 278.17869586301316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 89,
			"seed": 2032860703,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "wsTNs44g",
					"type": "text"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "yJPwbTekUSZw8vm6APITH",
					"type": "arrow"
				}
			],
			"updated": 1667362749687,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 351,
			"versionNonce": 1340120113,
			"isDeleted": false,
			"id": "wsTNs44g",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1979.8161405795163,
			"y": 310.67869586301316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 95,
			"height": 24,
			"seed": 1101182801,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1667362613568,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 3,
			"text": "AFE_TRIM",
			"rawText": "AFE_TRIM",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "1DXJsGUwwf5Yhc026qC8F",
			"originalText": "AFE_TRIM"
		},
		{
			"id": "xGNfLdpOYFnPnUxj_YeO1",
			"type": "line",
			"x": 1379.3160591993071,
			"y": 471.25654959565236,
			"width": 348.8000488281252,
			"height": 76.7999267578125,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 599830079,
			"version": 273,
			"versionNonce": 564317759,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362687019,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0
				],
				[
					316.8000488281252,
					3.199951171875
				],
				[
					155.19995117187523,
					76.7999267578125
				],
				[
					-32,
					0
				]
			],
			"lastCommittedPoint": [
				-32,
				0
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "rectangle",
			"version": 403,
			"versionNonce": 1606640095,
			"isDeleted": false,
			"id": "MB26z2G6dUw5Wk5m-LZqJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1447.7434187321358,
			"y": 844.0209600576945,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 89,
			"seed": 34990673,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "DkpmNHuR",
					"type": "text"
				},
				{
					"id": "6wNYJIGzrswwbVq9N7hNJ",
					"type": "arrow"
				},
				{
					"id": "ncO7vNZlL-0jWA9AMN0Bq",
					"type": "arrow"
				}
			],
			"updated": 1667362740706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 381,
			"versionNonce": 950039345,
			"isDeleted": false,
			"id": "DkpmNHuR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1497.2434187321358,
			"y": 876.5209600576945,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 24,
			"seed": 1112629055,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1667362725287,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 3,
			"text": "CTLE1/2",
			"rawText": "CTLE1/2",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "MB26z2G6dUw5Wk5m-LZqJ",
			"originalText": "CTLE1/2"
		},
		{
			"id": "qchnuGuqEG19CRf0kjfxM",
			"type": "arrow",
			"x": 1504.1323347477603,
			"y": 369.41003883373605,
			"width": 3.555501302083485,
			"height": 90.66663953993066,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1735189777,
			"version": 37,
			"versionNonce": 166023889,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362732415,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					3.555501302083485,
					90.66663953993066
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "uOHwbAmora25BFTvhCxtK",
				"focus": 0.06305008060845785,
				"gap": 3.831272780293091
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "z1PJwNnSC3Rtrq227xe45",
			"type": "arrow",
			"x": 1525.4656138276216,
			"y": 543.6321796757502,
			"width": 3.5555013020832575,
			"height": 103.11116536458326,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1748291761,
			"version": 25,
			"versionNonce": 454717233,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362736341,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					3.5555013020832575,
					103.11116536458326
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": {
				"elementId": "9K6c3X9aSrNCfZ4H2lxUB",
				"focus": -0.05753587604267115,
				"gap": 12.4577642883919
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "ncO7vNZlL-0jWA9AMN0Bq",
			"type": "arrow",
			"x": 1532.5767520654688,
			"y": 753.4100117070002,
			"width": 3.5555013020832575,
			"height": 81.7778862847224,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1632067857,
			"version": 22,
			"versionNonce": 165039537,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362740706,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					3.5555013020832575,
					81.7778862847224
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "9K6c3X9aSrNCfZ4H2lxUB",
				"focus": 0.06338576086207726,
				"gap": 5.208902378274843
			},
			"endBinding": {
				"elementId": "MB26z2G6dUw5Wk5m-LZqJ",
				"focus": -0.008480517515306946,
				"gap": 8.833062065971944
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "nQ00hZqbTFBfULNEHlLBF",
			"type": "arrow",
			"x": 1777.9100040185938,
			"y": 367.6322881826944,
			"width": 218.66658528645826,
			"height": 90.66663953993054,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2047045521,
			"version": 36,
			"versionNonce": 416159775,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362745464,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-218.66658528645826,
					90.66663953993054
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "OO6j9nHhAbHDC3ZNobjZ7",
				"focus": -0.5725443726024907,
				"gap": 2.4537143899936495
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "yJPwbTekUSZw8vm6APITH",
			"type": "arrow",
			"x": 2017.910139652275,
			"y": 367.6322881826944,
			"width": 424.88891601562545,
			"height": 97.77777777777771,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1488174143,
			"version": 50,
			"versionNonce": 1549690929,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362749687,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-424.88891601562545,
					97.77777777777771
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "1DXJsGUwwf5Yhc026qC8F",
				"focus": -0.6527047967925621,
				"gap": 1
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "E-KGEvX7Xtty7f5HLhn3O",
			"type": "arrow",
			"x": 1205.4656138276212,
			"y": 364.0766512469305,
			"width": 268.4444173177087,
			"height": 96.0000271267362,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 698628625,
			"version": 42,
			"versionNonce": 861165055,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362754181,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					268.4444173177087,
					96.0000271267362
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "OitInrRod0ly0KMRuVxn2",
				"focus": 0.6209195267351411,
				"gap": 1
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "1gC3xSY2hlelmgatbdFTy",
			"type": "arrow",
			"x": 960.1322262408155,
			"y": 367.6322881826944,
			"width": 492.4445258246533,
			"height": 95.99989149305554,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 662126111,
			"version": 50,
			"versionNonce": 161616977,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1667362757576,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					492.4445258246533,
					95.99989149305554
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "x5NOCHn16Y9nI4NvfDgEM",
				"focus": 0.7882341508739488,
				"gap": 5.653421421243763
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 3,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%