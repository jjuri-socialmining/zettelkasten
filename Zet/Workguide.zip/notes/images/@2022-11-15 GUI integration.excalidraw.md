---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
python: *.pyd, *.py to GUI ^0Y8orJtX

Copy C source code, header ^0TCDqno2


# Embedded files
07c74ae2971fb887e69ee23923b96335188d3f81: [[Pasted Image 20221115105658_788.png]]
603aea772b1f7bad06133295d0d77b9f3c88faea: [[Pasted Image 20221115105740_942.png]]
eec0dba68450f142e972cf1034800b99e9b27de9: [[Pasted Image 20221115110056_060.png]]
00a157ba07af12b352ac723d1bbc55d64730321b: [[Pasted Image 20221115110158_108.png]]

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "Gg4EAra5BrNXYvdNqClEm",
			"type": "image",
			"x": -504.97653329353125,
			"y": -415.03395383364153,
			"width": 666.8195604174423,
			"height": 448.95552667545417,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 509182921,
			"version": 113,
			"versionNonce": 1151095657,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "07c74ae2971fb887e69ee23923b96335188d3f81",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "g6d-DCvEjS7XP2jPwjqSV",
			"type": "image",
			"x": -403.8570375445847,
			"y": 123.82192356550553,
			"width": 500.1307155873196,
			"height": 315.1150391020759,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 336153415,
			"version": 140,
			"versionNonce": 546550695,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "603aea772b1f7bad06133295d0d77b9f3c88faea",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "7JrOayVpaeYLTSDkVf2wt",
			"type": "image",
			"x": -1193.5988313044654,
			"y": -426.56004181477385,
			"width": 639.6794349180235,
			"height": 497.00439044782837,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 840016041,
			"version": 78,
			"versionNonce": 711982665,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "eec0dba68450f142e972cf1034800b99e9b27de9",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "BcUaEN2m_uBRo8kLLktcO",
			"type": "image",
			"x": -1224.142613661791,
			"y": 95.71674628077463,
			"width": 784.2336539278424,
			"height": 383.708863812648,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1387663465,
			"version": 95,
			"versionNonce": 1934403271,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "00a157ba07af12b352ac723d1bbc55d64730321b",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "mng4uCaSdOejK21oCevqt",
			"type": "arrow",
			"x": -1051.2743919268808,
			"y": -225.81956905771767,
			"width": 834.7588963384746,
			"height": 157.6169071040402,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 431500457,
			"version": 454,
			"versionNonce": 91833833,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668485052567,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					203.74146841063316,
					89.78141381094588
				],
				[
					401.47439794364016,
					88.71264424632272
				],
				[
					834.7588963384746,
					-67.83549329309432
				]
			],
			"lastCommittedPoint": [
				875.3691210298548,
				-48.09717868934587
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "1_1S4BXAB-aM1cuuqVZp2",
			"type": "freedraw",
			"x": -945.5111348275967,
			"y": 253.9030409801793,
			"width": 38.477742951476785,
			"height": 202.0082931990056,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1575717703,
			"version": 115,
			"versionNonce": 1935206759,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668484994284,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.0687287921223287,
					0
				],
				[
					2.13753912924642,
					0
				],
				[
					5.344051685620116,
					1.0688103371239777
				],
				[
					8.550564241993925,
					4.2752821209969625
				],
				[
					12.825887135491712,
					7.481753904869834
				],
				[
					12.825887135491712,
					9.619415351618727
				],
				[
					13.89469747261569,
					12.825887135491598
				],
				[
					16.03239969186552,
					16.032399691865407
				],
				[
					17.10112848398785,
					18.170020366113476
				],
				[
					19.238830703237568,
					22.445343259611263
				],
				[
					20.307641040361545,
					23.51415359673524
				],
				[
					21.376451377485637,
					24.583004706360157
				],
				[
					22.445343259611263,
					26.72066615310905
				],
				[
					22.445343259611263,
					27.789476490233028
				],
				[
					22.445343259611263,
					29.92713793698192
				],
				[
					22.445343259611263,
					30.995948274106013
				],
				[
					23.514072051733706,
					33.13365049335573
				],
				[
					23.514072051733706,
					34.20246083047971
				],
				[
					23.514072051733706,
					35.2712711676038
				],
				[
					23.514072051733706,
					36.34008150472778
				],
				[
					23.514072051733706,
					39.54659406110159
				],
				[
					23.514072051733706,
					42.75302507247363
				],
				[
					23.514072051733706,
					43.821916954599374
				],
				[
					23.514072051733706,
					44.89072729172335
				],
				[
					23.514072051733706,
					49.16605018522114
				],
				[
					23.514072051733706,
					50.234860522345116
				],
				[
					23.514072051733706,
					51.30367085946921
				],
				[
					23.514072051733706,
					52.372481196593185
				],
				[
					23.514072051733706,
					55.578993752966994
				],
				[
					23.514072051733706,
					56.64780409009097
				],
				[
					23.514072051733706,
					58.78542476433904
				],
				[
					23.514072051733706,
					59.85431664646478
				],
				[
					23.514072051733706,
					60.92312698358876
				],
				[
					23.514072051733706,
					64.12955799496092
				],
				[
					23.514072051733706,
					65.19844987708655
				],
				[
					23.514072051733706,
					67.33607055133461
				],
				[
					23.514072051733706,
					68.4048808884587
				],
				[
					23.514072051733706,
					69.47369122558268
				],
				[
					23.514072051733706,
					70.54258310770842
				],
				[
					23.514072051733706,
					73.74901411908047
				],
				[
					23.514072051733706,
					76.95552667545428
				],
				[
					23.514072051733706,
					81.23084956895207
				],
				[
					23.514072051733706,
					82.29965990607604
				],
				[
					23.514072051733706,
					86.57498279957383
				],
				[
					23.514072051733706,
					87.64379313669781
				],
				[
					24.582963933859332,
					91.9191160301956
				],
				[
					25.651855815985073,
					94.05673670444367
				],
				[
					29.92709716448121,
					98.33205959794145
				],
				[
					30.99590750160519,
					100.46968027218952
				],
				[
					33.13352817585326,
					101.5384906093135
				],
				[
					34.202338512977235,
					102.60738249143924
				],
				[
					36.34004073222695,
					104.74500316568731
				],
				[
					37.408851069351044,
					105.81381350281129
				],
				[
					38.477742951476785,
					106.88262383993538
				],
				[
					38.477742951476785,
					107.95151572206112
				],
				[
					36.34004073222695,
					109.0203260591851
				],
				[
					35.271230395102975,
					110.08913639630907
				],
				[
					33.13352817585326,
					110.08913639630907
				],
				[
					28.85828682735712,
					112.22675707055714
				],
				[
					26.7205846081074,
					114.36445928980686
				],
				[
					26.7205846081074,
					115.43326962693095
				],
				[
					25.651855815985073,
					116.50207996405493
				],
				[
					24.582963933859332,
					118.63978218330465
				],
				[
					23.514072051733706,
					118.63978218330465
				],
				[
					23.514072051733706,
					119.70859252042874
				],
				[
					22.445343259611263,
					121.8462131946768
				],
				[
					21.376451377485637,
					123.98391541392652
				],
				[
					19.238830703237568,
					125.0527257510505
				],
				[
					18.169938821111828,
					127.19034642529857
				],
				[
					18.169938821111828,
					129.3280486445483
				],
				[
					17.10112848398785,
					132.53447965592034
				],
				[
					16.03239969186552,
					136.80980254941812
				],
				[
					16.03239969186552,
					138.9474232236662
				],
				[
					16.03239969186552,
					140.01631510579193
				],
				[
					16.03239969186552,
					142.15393578004
				],
				[
					16.03239969186552,
					143.22274611716398
				],
				[
					14.963507809739781,
					146.4292586735378
				],
				[
					14.963507809739781,
					148.56687934778586
				],
				[
					14.963507809739781,
					151.77339190415955
				],
				[
					14.963507809739781,
					153.91101257840762
				],
				[
					14.963507809739781,
					154.9798229155316
				],
				[
					14.963507809739781,
					156.04871479765734
				],
				[
					14.963507809739781,
					157.11752513478143
				],
				[
					14.963507809739781,
					158.1863354719054
				],
				[
					14.963507809739781,
					159.2551458090294
				],
				[
					14.963507809739781,
					162.4616583654032
				],
				[
					14.963507809739781,
					164.59927903965126
				],
				[
					14.963507809739781,
					165.66808937677524
				],
				[
					14.963507809739781,
					166.73698125890098
				],
				[
					14.963507809739781,
					168.87460193314905
				],
				[
					14.963507809739781,
					171.01222260739712
				],
				[
					14.963507809739781,
					172.08111448952275
				],
				[
					14.963507809739781,
					173.1500063716485
				],
				[
					14.963507809739781,
					174.21873516377082
				],
				[
					14.963507809739781,
					175.2875455008949
				],
				[
					14.963507809739781,
					177.42524772014463
				],
				[
					14.963507809739781,
					179.56294993939434
				],
				[
					12.825887135491712,
					181.70048906864065
				],
				[
					11.756995253365972,
					183.83819128789048
				],
				[
					11.756995253365972,
					185.9758935071402
				],
				[
					10.688184916241994,
					189.1824060635139
				],
				[
					9.619456124119665,
					190.25113485563622
				],
				[
					8.550564241993925,
					191.31994519276031
				],
				[
					7.481672359868185,
					192.38883707488606
				],
				[
					6.412943567745856,
					193.45764741201003
				],
				[
					6.412943567745856,
					195.59534963125975
				],
				[
					4.275241348496138,
					198.8017806426318
				],
				[
					4.275241348496138,
					199.8705909797559
				],
				[
					3.2064310113721604,
					200.93940131687987
				],
				[
					2.13753912924642,
					202.0082931990056
				],
				[
					1.0687287921223287,
					202.0082931990056
				],
				[
					0,
					202.0082931990056
				],
				[
					0,
					202.0082931990056
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				202.0082931990056
			]
		},
		{
			"id": "Td9uo4IaVKKOXQZCPzxg6",
			"type": "arrow",
			"x": -889.9322633921322,
			"y": 357.57923380874263,
			"width": 716.7730380709806,
			"height": 187.46417402119818,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 974259337,
			"version": 187,
			"versionNonce": 1282047209,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668485082887,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0
				],
				[
					245.83012860860333,
					40.61536362572474
				],
				[
					716.7730380709806,
					-146.84881039547344
				]
			],
			"lastCommittedPoint": [
				711.8385300098248,
				-119.70859252042874
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "0Y8orJtX",
			"type": "text",
			"x": -870.1724935217743,
			"y": -96.09069212859839,
			"width": 227,
			"height": 23,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 400761479,
			"version": 69,
			"versionNonce": 1037833801,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668485072675,
			"link": null,
			"locked": false,
			"text": "python: *.pyd, *.py to GUI",
			"rawText": "python: *.pyd, *.py to GUI",
			"fontSize": 20,
			"fontFamily": 2,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 19,
			"containerId": null,
			"originalText": "python: *.pyd, *.py to GUI"
		},
		{
			"type": "arrow",
			"version": 660,
			"versionNonce": 1319211527,
			"isDeleted": false,
			"id": "cOMVnNs3wHcLlg0tzmt7e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1066.6345778910827,
			"y": -50.91360583013716,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 839.6934985193388,
			"height": 202.0281384924013,
			"seed": 2080599111,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1668485077142,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					256.7883712651418,
					29.332748864703376
				],
				[
					516.2034045202639,
					-19.848227253856066
				],
				[
					839.6934985193388,
					-172.69538962769792
				]
			]
		},
		{
			"id": "0TCDqno2",
			"type": "text",
			"x": -796.6995077079647,
			"y": 327.8221532635812,
			"width": 257,
			"height": 23,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 109446471,
			"version": 32,
			"versionNonce": 1433388489,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1668485112614,
			"link": null,
			"locked": false,
			"text": "Copy C source code, header",
			"rawText": "Copy C source code, header",
			"fontSize": 20,
			"fontFamily": 2,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 19,
			"containerId": null,
			"originalText": "Copy C source code, header"
		},
		{
			"id": "XMDcu9CcZpFwHhQSHwssm",
			"type": "image",
			"x": -1048.3527282604127,
			"y": -396.27090032245223,
			"width": 479.5168231055033,
			"height": 372.5646837584694,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 89741865,
			"version": 83,
			"versionNonce": 843795753,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "64ed35aad47122e15f6363e12a5119e5d8211b57",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "sQfc7EONIMwG4tPNrGoyP",
			"type": "freedraw",
			"x": -241.614204329527,
			"y": -292.01019969941865,
			"width": 119.74147266929708,
			"height": 57.288062789939204,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 606316617,
			"version": 29,
			"versionNonce": 1689925095,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.4087375381475908,
					2.3478720131234923
				],
				[
					8.921884989322166,
					7.982750514346321
				],
				[
					15.49596961688843,
					11.269792828129425
				],
				[
					28.644031394969602,
					19.252543342475747
				],
				[
					41.79209317305077,
					25.357024906870265
				],
				[
					53.53145323866812,
					31.93105579591088
				],
				[
					58.696800328086795,
					34.74849504652224
				],
				[
					71.37529486868004,
					41.79211108589266
				],
				[
					77.94934367056254,
					44.13998309901615
				],
				[
					80.76678292117396,
					45.07915339967582
				],
				[
					82.64508769680947,
					46.01828787465169
				],
				[
					84.99295970993296,
					46.487873024981525
				],
				[
					87.3408317230564,
					47.896592650287204
				],
				[
					90.62783821115579,
					48.366159887775154
				],
				[
					95.32358223740272,
					50.71404981374053
				],
				[
					97.67145425052621,
					51.6531842887164
				],
				[
					108.00211260367973,
					54.940208689657624
				],
				[
					110.34998461680323,
					55.409775927145574
				],
				[
					113.63699110490256,
					55.8793431646335
				],
				[
					116.9239975930019,
					56.81849555245128
				],
				[
					117.39360065617365,
					56.81849555245128
				],
				[
					118.80230236863741,
					57.288062789939204
				],
				[
					119.27186960612539,
					57.288062789939204
				],
				[
					119.74147266929708,
					57.288062789939204
				],
				[
					119.74147266929708,
					57.288062789939204
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				119.74147266929708,
				57.288062789939204
			]
		},
		{
			"id": "1PDchUf_UEF1lG5AgOkF1",
			"type": "freedraw",
			"x": 178.63250808073542,
			"y": -228.81058912618215,
			"width": 0.0001,
			"height": 0.0001,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1168165737,
			"version": 5,
			"versionNonce": 60407817,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0.0001,
				0.0001
			]
		},
		{
			"id": "ghImrucO0ijF_pNympJAm",
			"type": "image",
			"x": -74.34601399100606,
			"y": -388.6528627869512,
			"width": 479.5168231055033,
			"height": 372.5646837584694,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 407975945,
			"version": 6,
			"versionNonce": 1810424071,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "64ed35aad47122e15f6363e12a5119e5d8211b57",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "gEwhLv69PHGTUkFdu0McD",
			"type": "freedraw",
			"x": 116.93890350333857,
			"y": -220.79844538944087,
			"width": 553.6391199832611,
			"height": 0.8012327120158034,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1715964361,
			"version": 40,
			"versionNonce": 1280759529,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.801141020307341,
					0
				],
				[
					-4.006071868370668,
					0.8012327120158034
				],
				[
					-10.415689053274718,
					0.8012327120158034
				],
				[
					-18.42783279001594,
					0.8012327120158034
				],
				[
					-40.861859704013796,
					0.8012327120158034
				],
				[
					-76.11536549904213,
					0.8012327120158034
				],
				[
					-122.58570136765252,
					0.8012327120158034
				],
				[
					-165.8513508994222,
					0.8012327120158034
				],
				[
					-205.11086743501562,
					0.8012327120158034
				],
				[
					-249.97886013520565,
					0.8012327120158034
				],
				[
					-274.01529134542943,
					0.8012327120158034
				],
				[
					-283.6298393783967,
					0.8012327120158034
				],
				[
					-301.25659227591086,
					0.8012327120158034
				],
				[
					-334.907571519102,
					0.8012327120158034
				],
				[
					-360.54640702555184,
					0.8012327120158034
				],
				[
					-391.79377982440394,
					0.8012327120158034
				],
				[
					-425.44482019540067,
					0.8012327120158034
				],
				[
					-454.28852542210825,
					0.8012327120158034
				],
				[
					-478.32495663233203,
					0.8012327120158034
				],
				[
					-492.746778681783,
					0.8012327120158034
				],
				[
					-501.5601245666372,
					0.8012327120158034
				],
				[
					-514.3796034476677,
					0.8012327120158034
				],
				[
					-519.1868774641514,
					0.8012327120158034
				],
				[
					-531.2050930692633,
					0.8012327120158034
				],
				[
					-542.4220453984567,
					0.8012327120158034
				],
				[
					-548.8317848389719,
					0.8012327120158034
				],
				[
					-551.2354524111165,
					0.8012327120158034
				],
				[
					-553.6391199832611,
					0.8012327120158034
				],
				[
					-551.2354524111165,
					0.8012327120158034
				],
				[
					-535.2111038098284,
					0
				],
				[
					-495.1504462539276,
					0
				],
				[
					-479.12615878044505,
					0
				],
				[
					-447.87878598159296,
					0
				],
				[
					-414.2278067384018,
					0
				],
				[
					-407.0168651497735,
					0
				],
				[
					-407.0168651497735,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-407.0168651497735,
				0
			]
		},
		{
			"id": "maZ3k8t5rMkAfqMDgJorU",
			"type": "freedraw",
			"x": -955.1305909517163,
			"y": 233.5953183948161,
			"width": 17.101128483987736,
			"height": 54.5101834158429,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1640193225,
			"version": 39,
			"versionNonce": 1863193033,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1668484988019,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.0687287921223287,
					0
				],
				[
					2.137620674248069,
					0
				],
				[
					3.2065125563738093,
					0
				],
				[
					5.344051685620116,
					0
				],
				[
					6.412943567745856,
					0
				],
				[
					7.481753904869834,
					1.0688103371239777
				],
				[
					8.550564241993925,
					3.206471783872871
				],
				[
					9.619456124119552,
					4.275322893497787
				],
				[
					11.756995253365972,
					5.344133230621765
				],
				[
					12.825887135491712,
					6.412943567745742
				],
				[
					14.963507809739667,
					7.481794677370658
				],
				[
					14.963507809739667,
					8.550605014494636
				],
				[
					14.963507809739667,
					9.619456124119552
				],
				[
					16.032399691865407,
					11.75707679836762
				],
				[
					17.101128483987736,
					12.825927907992423
				],
				[
					17.101128483987736,
					13.894738245116514
				],
				[
					17.101128483987736,
					14.963589354741316
				],
				[
					17.101128483987736,
					17.101210028989385
				],
				[
					17.101128483987736,
					20.307722585363194
				],
				[
					17.101128483987736,
					22.445343259611263
				],
				[
					17.101128483987736,
					25.65185581598496
				],
				[
					17.101128483987736,
					26.72066615310905
				],
				[
					17.101128483987736,
					29.92713793698192
				],
				[
					17.101128483987736,
					30.995989046606837
				],
				[
					17.101128483987736,
					32.064799383730815
				],
				[
					17.101128483987736,
					34.20246083047971
				],
				[
					17.101128483987736,
					35.271271167603686
				],
				[
					17.101128483987736,
					39.54659406110147
				],
				[
					17.101128483987736,
					43.821876182098435
				],
				[
					17.101128483987736,
					45.95953762884733
				],
				[
					17.101128483987736,
					47.028388738472245
				],
				[
					17.101128483987736,
					49.166009412720314
				],
				[
					17.101128483987736,
					52.372481196593185
				],
				[
					17.101128483987736,
					53.441373078718925
				],
				[
					17.101128483987736,
					54.5101834158429
				],
				[
					17.101128483987736,
					54.5101834158429
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				17.101128483987736,
				54.5101834158429
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 2,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%