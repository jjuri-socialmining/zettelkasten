---
title: 'Marvell In the News — Week of October 17, 2022'
created: 2022-Oct-24
tags:
  - 'daily'
publish: False
---
[**Marvell advances to 3nm with TSMC**](https://www.youtube.com/watch?v=mUYoLecCWoI)

Marvell's first 3nm silicon is now in fabrication with Taiwan Semiconductor Manufacturing Company (TSMC) on its 3nm shuttle. Hugh Durdan, VP of ASIC Marketing at Marvell explains.
