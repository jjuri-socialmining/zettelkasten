```  
Username:  inphi-corp\Username
Default password: tudcWNTEcn8rq3EJvukH
Please use this default password and change by accessing link below:
[https://las-rds-01/RDWeb/Pages/en-US/password.aspx](https://las-rds-01/RDWeb/Pages/en-US/password.aspx)
```

May 09, 2022
```
3Kt#72Ib$
```

[[@2022-08-01]]
```
dutran
3Kt#73Ib$
```
[[@2022-10-24]]
```
dutran
3Kt#74Ib$
```
