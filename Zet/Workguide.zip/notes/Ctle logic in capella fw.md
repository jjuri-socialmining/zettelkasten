---
title: Ctle logic in capella
created: 2022-Nov-02
tags:
  - 'permanent/common'
publish: False
---

`cpl_rx_ctle.c`

![[Ctle logic in capella 2022-11-02 11.09.12.excalidraw]]