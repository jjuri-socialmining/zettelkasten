---
title: Level Transition Parameter
created: 2022-May-19
tags:
  - 'inbox'
aliases:
  - LTP
---


Need enable histogram qc

[[ctc script to enable qc.py]]


