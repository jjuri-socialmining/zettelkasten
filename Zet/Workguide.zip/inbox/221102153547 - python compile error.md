---
title: python compile error
UID: 221102153547
created: 02-Nov-2022
tags:
  - 'created/2022/Nov/02'
  - 'seed'
  - 'permanent/fact'
aliases: '221102153547'
publish: False
---
## Notes:
```
  inphi_rtos.c
  cpl_api.c
  cpl_api.h
C:\usr\jenkins\workspace\capella\capella.api\capella.api.python.wrapper.win\hsc\capella\api\build-output\python\cpl_api.c : fatal error C1083: Cannot open compiler generated file: 'Release\Intermediate\cpl_api.obj': Permission denied
cl : Command line error D8040: error creating or communicating with child process
```
-> Just rebuild -> SUCCESS!?