---
title: The Multiverse
UID: 220625175756
created: 25-Jun-2022
tags:
  - 'created/2022/Jun/25'
  - 'permanent/concept'
aliases:
  - Đa vũ trụ
publish: False
---
## Notes:

Phim liên quan:
- [[Doctor Strange In The Multiverse Of Madness (2022)]]
- [[Spider-Man - No Way Home (2021)]]


Các bộ phim đa vũ trụ
- https://wowhay.com/2022/05/dr-strange-2-10-phim-khong-thuoc-mcu-co-da-vu-tru-doc-dao.html