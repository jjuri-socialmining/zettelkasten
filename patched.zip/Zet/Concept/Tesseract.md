---
title: Tesseract
UID: 220626202447
created: 26-Jun-2022
tags:
  - 'created/2022/Jun/26'
  - 'permanent/concept'
aliases:
  - Viên đá Không gian
publish: False
---
## Notes:
Tesseract là khối lập phương chứa viên đá không gian.


Dòng thời gian của khối lập phương trong [[Vũ trụ điện ảnh Marvel]]:
- https://wowhay.com/2021/06/dong-thoi-gian-cua-khoi-tesseract-trong.html
