---
title: Darkhold Book
UID: 220625184227
created: 25-Jun-2022
tags:
  - 'created/2022/Jun/25'
  - 'permanent/concept'
aliases:
  - 
publish: False
---
## Notes:
Là quyển sách phép thuật mà [[Wanda Maximoff]] nắm giữ.



