---
title: Pin CMOS
UID: 220625164009
created: 25-Jun-2022
tags:
  - 'created/2022/Jun/25'
  - 'permanent/concept'
aliases:
  - 
publish: False
---
## Notes:
Pin CMOS tên gọi viên pin dùng để cung cấp điện cho mainboard máy tính, giúp main board lưu trữ các setting, thời gian,...

[[CRC2032]] thường được lựa chọn là pin CMOS.





