---
title: Doctor Strange
UID: 220625182926
tags:
  - 'created/2022/Jun/25'
  - 'permanent/people'
birth:
death:
aliases:
  - Stephen Strange
publish: False
---
up:: [[People MOC]]

## Notes:
Strange tên thật là Stephen?

Phim về Strange
- [[Doctor Strange (2016)]]
- [[Doctor Strange In The Multiverse Of Madness (2022)]]

## Quiz
[[❔220625-2116 - Doctor Strange dùng gì để mở phòng chứa Vishanti trong bộ phim Doctor Strange In The Multiverse Of Madness]]