---
title: Wanda Maximoff
UID: 220625180831
tags:
  - 'created/2022/Jun/25'
  - 'permanent/people'
birth:
death:
aliases:
  - Scarlet Witch
publish: False
---
up:: [[People MOC]]

## Notes:


## Ideas & thoughts:
