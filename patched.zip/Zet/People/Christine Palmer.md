---
title: Christine Palmer
UID: 220625205556
tags:
  - 'created/2022/Jun/25'
  - 'permanent/people'
birth:
death:
publish: False
---
up:: [[People MOC]]

## Notes:
Nhân vật trong phim [[Vũ trụ điện ảnh Marvel]], người yêu của [[Doctor Strange]]