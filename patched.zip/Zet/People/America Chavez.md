---
title: America Chavez
UID: 220625180308
tags:
  - 'created/2022/Jun/25'
  - 'permanent/people'
birth:
death:
aliases:
  - Chavez
publish: False
---
up:: [[People MOC]]

## Notes:
Một nhân vật trong bộ phim [[Doctor Strange In The Multiverse Of Madness (2022)]]

[[Vũ trụ điện ảnh Marvel]]