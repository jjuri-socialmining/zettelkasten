---
title: 'Eternals (2021)'
UID: 220625221026
tags:
  - 'created/2022/Jun/25'
  - 'source/film'
aliases:
  - 
publish: False
---
- metadata:
	- url:
	- author:
	- category:
	- Nhân vật: [[Ikaris]], [[Sersi]], [[Ajak]], [[Kingo]], [[Phastos]]

[[Chủng loài Eternal|The Eternal]]

Lưỡng hà 5000 TCN, Eternal đến để bảo vệ loài người (human) khỏi các sinh vật gây hại  [[Chủng loài Deviant]]

Rồi các Eternal này sống 7000 năm tới thời hiện đại ngày nay luôn.

Sau khi Ajak bị giết hại, Sersi được chọn làm người thay thế. Cô nhận được viên ngọc để giao tiếp được với [[Arishem]]. Và Arishem cho cô biết sứ mệnh dến trái đất này là để chuẩn bị cho sự sinh ra của [[Chủng loài Celestials|Celestials]] tại trái đất, và Celestials đột sinh tại trái đất là [[Cliestials Tiamut]]

> [[World Force]] là quê hương của các [[Chủng loài Eternal|The Eternal]], nơi các Eternals được lập trình để thực hiện sứ mệnh.

Các Eternal được Arishem tạo ra sau, để tránh lặp lại sai lầm khi tạo ra các Deviant tiến hóa, và không thể kiểm soát chúng. Các Deviant ban đầu là để giết các sinh vật ăn thịt, săn mồi để mở đường cho các human, nhưng chúng có khả năng tiến hóa khiến cho Arishem không thể kiểm soát nổi. Và Arishem đã tạo ra các Eternal vừa để giết Deviant vừa để phát triển cộng đồng người để chuẩn bị cho việc đột sinh tạo ra các Celestials.

> [!FACT]
> Lul, nhân vật có tên [[Vua Gilgamesh|Gilgamesh]] luôn, hehe, chắc ông này ở chết ở Lưỡng Hà luôn, sự bất tử nè. [[Sử thi Gilgamesh]] cũng bàn về sự bất tử





