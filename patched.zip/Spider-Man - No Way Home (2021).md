---
title: 'Spider-Man - No Way Home 2021'
UID: 220625175956
tags:
  - 'created/2022/Jun/25'
  - 'source/film'
aliases:
  - 
publish: False
---
- metadata:
	- url:
	- author:
	- category:

[[Spiderman]] tìm đến [[Doctor Strange]] để thay đổi quá khứ, vì hiện tại những việc cậu làm đang ảnh hưởng đến cuộc sống của những người thân xung quanh cậu.
