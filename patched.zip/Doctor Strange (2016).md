---
title: 'Doctor Strange (2016)'
UID: 220625205111
tags:
  - 'created/2022/Jun/25'
  - 'source/film'
aliases:
  - 
publish: False
---
- metadata:
	- url:
	- author:
	- category:
	- Nhân vật: [[Doctor Strange]], [[Christine Palmer]], [[Karl Mordo]], [[Ancient One]] 

