---
title: 'Shang-Chi and the legend of the ten rings (2021)'
UID: 220626082539
tags:
  - 'created/2022/Jun/26'
  - 'source/film'
aliases:
  - 
publish: False
---
- metadata:
	- url:
	- author:
	- category:
	- Nhân vật: [[Wong]], [[Shang Chi]]


