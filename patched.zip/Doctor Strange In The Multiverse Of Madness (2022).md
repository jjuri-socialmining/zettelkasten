---
title: 'Doctor Strange In The Multiverse Of Madness 2022'
UID: 220625175237
tags:
  - 'created/2022/Jun/25'
  - 'source/film'
aliases:
  - 
publish: False
---
- metadata:
	- url:
	- author:
	- category:
	- Nhân vật: [[Doctor Strange]], [[America Chavez]], [[Wanda Maximoff]], Wong, [[Christine Palmer]], [[Karl Mordo]]

Mở đầu phim [[Doctor Strange]] nằm mơ thấy mình đang hút sức mạnh của đứa cháu để chiến đấu với một con quái vật đa vũ trụ.

Không lâu sau đó, con quái vật xuất hiện ở ngoài đường phố cùng với đứa cháu gái, và có vẻ ông không quen biết nó, chỉ biết là đã gặp nó ở trong mơ.

> [!IDEA]
> Phải làm quen khái niệm [[The Multiverse]], cái này xuất hiện trong [[Spider-Man - No Way Home (2021)]]

Cô bé sau đó đã giải thích rằng những gì DStrange chứng kiến không phải là mơ, mà ông đang nhìn thấy một vũ trụ khác.

Cô bé này tên là [[America Chavez]]

DStrange đi gặp [[Wanda Maximoff]], ai dè Wanda là người muốn tiêu diệt cô vé Chavez. Wanda đòi Strange giao cô bé cho mình. Cô hăm doạ Strange rằng nếu không giao Chavez, người đi người đi tìm không phải là wanda mà sẽ là [[Wanda Maximoff|Scarlet Witch]], ý nói là cũng chính là mình nhưng trong vai trò của kẻ phản diện ấy.

Strange nói rằng Wanda đang giữ [[Darkhold Book]] #task/todo -> cái vẹo này là gì thế?

> [!IDEA]
> Tính ra [[Wanda Maximoff|Scarlet Witch]] mạnh he, viết lại được thực tại, mạnh hơn Strange còn gì

Quân của Strange chiến đấu với Wanda, tạo bức tường chắn tại bản doanh, nhưng Wanda đã xâm nhập vào suy nghĩ của những người tạo tường chắn, kết quả là tường chắn bị thủng và Wanda tấn công và xâm nhập vào trong để tìm cô bé Chavez.

Nhưng rất tiếc Strange cao tay, vừa bước vào thì Strange đã cho cô lạc vào thế giới gương, nhưng có lẽ điều này chỉ kéo dài thời gian Wanda tìm được cô bé.

Ngay khi Wanda đang hút sức mạnh của CHavez thì Strange lao vào cứu và cả hai cùng rơi vào một cánh cổng và du hành đa vũ trụ. Cảnh cổng đó trong phim hình ngôi sao 5 cánh và có ánh sáng màu trắng, viền cánh cổng giống như là đá thủy tinh

Hai người rơi vào một vũ trụ mà ở đó phiên bản Strange đã hy sinh mạng sống mình để giết [[Thanos]]

Doctor Strange và Chavez bị lừa cho uống thuốc và bị nhốt. Sau đó, nực cười là anh gặp lại Christine và anh được biết rằng vũ trụ của mình là 616, còn vũ trụ hiện tại hai người đang ở là 838. Họ bị nhốt lại để cách ly vì có khả năng mang phóng xạ gây bệnh từ vũ trụ khác tới. Ai dè, đứng sau cùng của cuộc bắt giữ này lại là [[Hội Illuminati]].

Darkhold Book sau đó bị một người của phe [[Doctor Strange]] phá hủy lợi dụng lúc Wanda đang "luyện công".  Wong bị ép nói ra có một bản sao của  Darkhold, và anh dắt Wanda đến đó.

[[Vishanti Book]]

> Wanda đang bị cầm tù trong trong một phiên bản khác của mình

strange cùng Christine bị Wanda đẩy vô một vũ trụ khác, Strange đi tim strange ở vũ trụ đó và phát hiện ra anh ta đang nắm giữ quyển [[Darkhold Book]], sau khi đánh nhau thì Strange lấy được quyển sách và bắt đầu tìm kiếm [[Wanda Maximoff|Scarlet Witch]] ở thực tại của mình

Strange ở thực tại này đã khích lệ [[America Chavez|Chavez]] sử dụng sức mạnh của mình để đánh bại [[Wanda Maximoff|Scarlet Witch]]. Chavez đã cực kỳ thông minh đưa cô đến thực tại tồn tại những đứa con của cô. Và cô đã nhận ra rằng cô không được làm hại ai nữa, cô phải đóng quyển sách [[Darkhold Book]] và phá hủy nó ở tất cả các vũ trụ

> Khúc cuối khi nói chuyện với [[Christine Palmer|Christine]] ở vũ trụ 838, [[Doctor Strange]] nói rằng: không phải mình không muốn quan tâm ai hoặc ai quan tâm mình, chỉ là strange sợ. Christine mới nói rằng hãy đối diện với nỗi sợ

## Quiz
- [[❔220625-1813 Tại sao Wanda đòi Strange giao Chavez cho mình]]
