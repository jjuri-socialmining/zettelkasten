---
aliases:
  - Kang The Conqueror
---

- He Who Remains một nhân vật tối cao tạo ra các dòng thời gian trong [[Vũ trụ điện ảnh Marvel]]. He Who Remains còn mạnh hơn cả [[Thanos]].
- Người quản lý [[Cơ quan quản lý phương sai thời gian (TVA)]]
- 
Có nhiều biến thể (tên gọi): Kang The Conqueror

![[Pasted image 20220526221041.png]]

## Reference:
- https://congngheviet.com/kang-the-conqueror-phan-dien-tiep-theo-cua-mcu-se-manh-nhu-the-nao/
- Nhân vật này xuất hiện trong tập cuối phim [[Loki (2021)]]
- 
