---
title: Some thing to do with python
Notion_UID: 560f8008018a4e9cb86ffee45ebb2d23
---
# Some thing to do with python


## Notes:
Cần update

## Thoughts: